// GDIBALL.cpp: implementation of the GDIBALL class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
 #include "MISC.H"
#include "GDIBALL.h"
 #include "GDI_Process.h"
 
 //extern void GetFitColor(float X, float Y ,BYTE *indate,int mPitch,BYTE *outdate);



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
Vector3  Pos[128][128];
Vector3	 light(TABLE_WIDTH/2,TABLE_HEIGHT/2,-500);

short MAP[128][128];	 
short FJC [128][128];
float diff [128][128];
float spe [128][128];



	__inline Vector3 GDIBALL::CALEPOS(FLOAT X, FLOAT Y)
	{
	 FLOAT lng = raomag2 - (X* X + Y*Y);
	return  Vector3(X, Y, -sqrtf(lng)) ;
   	}



   //3X3��Ե����ݵ�
 __inline void  GDIBALL::CALEFJC	(FLOAT Xf, FLOAT Yf ,INT Ni ,INT Nj)
	 {
	   int i,j;
     Vector3 Toolver(0,0,0);
    FLOAT Xs, Ys;
    int Numin=0;// '��������
  
   	for (i=0;i<3;i++)
	{
		for (j=0;j<3;j++)
		{

            Xs = Xf + (FLOAT)i *0.33333f  - 0.33333f	;
            Ys = Yf + (FLOAT)j * 0.33333f - 0.33333f	;
            if (sqrtf(Xs* Xs + Ys*Ys) < rao)
			{
                Toolver += CALEPOS(Xs, Ys);
                Numin = Numin + 1 ;
            }

		}
	}

    if (Numin > 0)
	{
		Toolver.normalise();
        Toolver *= rao ;
        Pos[Ni][Nj] = Toolver ;
        MAP[Ni][Nj] = 2	;
        FJC[Ni][Nj] = Numin;
	}
	  
}




GDIBALL::GDIBALL()
{

}

GDIBALL::~GDIBALL()
{
	   
}

//������Ӱλ��
Vector3  GDIBALL::Cale_ShadowPos(Vector3 Ball_Pos)
{
	float PntX , PntY;
    float H, dx, dy;

    H = -light.Z;
    dx = Ball_Pos.X - light.X;
    dy = Ball_Pos.Y - light.Y;
    PntX = dx * (rao + H) / H + light.X;
    PntY = dy * (rao + H) / H + light.Y;

 return	Vector3(PntX,PntY);
//  return	Vector3(Ball_Pos.X,Ball_Pos.Y);
}

 //////////////////////////////////////////////////////////////
void GDIBALL::Shader_ball(Matrix3 BALL_Orientation,Vector3 Ball_Pos,BYTE *indate,int mPitchin,BYTE *outdate,int mPitchOut)
{

	int i,j;
	float IncX , IncY,lng;
	 float X , Y , XYmag2;


  IncX = Ball_Pos.X - (INT)Ball_Pos.X;
 IncY = Ball_Pos.Y  - (INT)Ball_Pos.Y;

   //    ����Ԥ����
   	for (i=0;i<BALLTEXW;i++)
	{
		for (j=0;j<BALLTEXW;j++)
		{
			

         MAP[i][j] = 0 ;
       X =  i - IncX - (banjin-0.5);
       Y = j - IncY - (banjin-0.5);
         Pos[i][j].X =X ;
         Pos[i][j].Y =Y ;

			XYmag2=(X*X + Y*Y); 
            lng = raomag2 - XYmag2 ;
			if (lng > 0	)
			{
			  Pos[i][j].Z = -sqrtf(lng)	;
                MAP[i][j] = 1 ;
			  	}


	   //    ��Ե�����
        lng = rao - sqrtf(XYmag2) ;
         if (fabs(lng) < 0.4714f)
			 CALEFJC (X, Y, i, j );
		}
	}
               




    //'����������
    Vector3 lightdir;
   goto AWAY ;
	AWAY:

    lightdir = light-Ball_Pos;
	 lightdir.normalise();

   	for (i=0;i<BALLTEXW;i++)
	{
		for (j=0;j<BALLTEXW;j++)
		{

            if (MAP[i][j] != 0)
			{
                diff[i][j] = dot(Pos[i][j], lightdir) / rao	;
                if (diff[i][j] < 0) diff[i][j] = 0 ;
                diff[i][j] = 0.3 + 0.7 * diff[i][j]	;
            }

		}
	}
	




    Matrix3 Mtmp ;
   Mtmp= transpose (BALL_Orientation);  //������

    Vector3 ver;
   DWORD C1=0, C2=0;   // C1�� ,C2 ����

    int ballDraw_X, ballDraw_Y;

    ballDraw_X = (INT)Ball_Pos.X - banjin;
	ballDraw_Y = (INT)Ball_Pos.Y - banjin; // '���½�����

   	for (i=0;i<BALLTEXW;i++)
	{
		for (j=0;j<BALLTEXW;j++)
		{


            if (MAP[i][j] != 0)
			{

                 ver= Mtmp *Pos[i][j]; //ת����
  
                if (ver.Z > 0)
				GetFitColor( 31.5f- ver.X, 31.5f +ver.Y ,indate,mPitchin,(BYTE*)&C1);
     			else
				GetFitColor(31.5f-ver.X , 31.5f-ver.Y ,indate,mPitchin,(BYTE*)&C1);


                 MIX_multself1((BYTE*)&C1,(INT)(diff[i][j]*255));  //  '��������

      			 BYTE*P= (outdate+(i + ballDraw_X)*4+(j + ballDraw_Y)*mPitchOut);

                if (MAP[i][j] == 2)
				{
				//�������
                    MIX_APLC((BYTE*)&C1,P, FJC[i][j]);
				}
                else
                   *(DWORD*)P = C1 ;
               
  
			}

		}
	}

					


}





