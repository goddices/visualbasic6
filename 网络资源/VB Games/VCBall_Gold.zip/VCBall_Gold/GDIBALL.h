// GDIBALL.h: interface for the GDIBALL class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GDIBALL_H)
#define AFX_GDIBALL_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

 #include "3dmath.h"




class GDIBALL  
{
public:
	GDIBALL();
	virtual ~GDIBALL();
void Shader_ball(Matrix3 BALL_Orientation,Vector3 Ball_Pos,BYTE *indate,int mPitchin,BYTE *outdate,int mPitchOut);
	 // 
  Vector3  GDIBALL::Cale_ShadowPos(Vector3 Ball_Pos);

  private:
   __inline Vector3 GDIBALL::CALEPOS(FLOAT X, FLOAT Y)  ;
__inline void  GDIBALL::CALEFJC	(FLOAT Xf, FLOAT Yf ,INT Ni ,INT Nj) ;

};

#endif // !defined(AFX_GDIBALL_H__853764B2_0181_42AB_B0A9_5DE56BB740AB__INCLUDED_)



    
