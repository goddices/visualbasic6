// GDIPIC.cpp: implementation of the GDIPIC class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MISC.H"		
#include "GDIPIC.h"
#include "GDI_Process.h"
// extern void GetFitColor(float X, float Y ,BYTE *indate,int mPitch,BYTE *outdate);


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////





GDIPIC::GDIPIC()
{

Bro_timeich=0;

}						   	

GDIPIC::~GDIPIC()
{
	
}


void GDIPIC:: ShaderTEXCOLOR(INT PntX , INT PntY  ,INT W , INT H,RECT *trimrect)
{
 	int i,j;
	 DWORD COLTMP;

		   for (i=0;i<W;i++)
		   {
			   for (j=0;j<H;j++)
			   {
				   COLTMP= *(DWORD*)(m_indate+4*i+j*m_Pitchin) ;
				   
				    ( *(DWORD*)(m_outdate+4*(i+PntX)+m_PitchOut*(j+PntY)) )= COLTMP;
   
			   }
		   }

}

void GDIPIC::iniTex(BYTE *indate,int Pitchin,BYTE *outdate,int PitchOut)
{	 
//   	m_trimrect.left=0;
//	m_trimrect.right=10000;
//	m_trimrect.top=10000;
//	m_trimrect.bottom=0;

	m_indate = indate;
	m_outdate	=outdate ;
	
    m_Pitchin=Pitchin;
	m_PitchOut=PitchOut;

  //  if(trimrect) m_trimrect =*trimrect;
}



		  

void GDIPIC::ShaderTEX(FLOAT PntX , FLOAT PntY  ,INT W , INT H,MIXOPERATE USEOperate,tagRECT *trimrect)
{
	
	
	int i,j,Showd_PX, Showd_PY	;
	FLOAT	IncX,IncY;	//����ֵϵ��
	   FLOAT K1 , K2, K3 , K4;
	   
	   
	   Showd_PX = (int)(PntX - W / 2)+1;Showd_PY = (INT)(PntY - H / 2)+1; //���½�����
	   
	   IncX = PntX - (int)PntX;
	   IncY = PntY - (int)PntY;
	   K1 = IncX * IncY;
	   K2 = (1 - IncX) * IncY;
	   K3 = IncX * (1 - IncY);
	   K4 = (1 - IncX) * (1 - IncY) ;

	   tagRECT rects={Showd_PX,Showd_PY+H-1,Showd_PX+W-1,Showd_PY};
	   
	   //���ñ߽�
		if(trimrect)
		{
	   rects.left= Max(rects.left,trimrect->left );
	   rects.right= Min(rects.right,trimrect->right );
	   rects.bottom= Max(rects.bottom,trimrect->bottom );
	   rects.top= Min(rects.top,trimrect->top );
		}
	   
	   
	   DWORD COLTMP;
	   
	   switch (USEOperate) 
	   {
		   
	   case BLEND_MULT:
		   
		   for (i=rects.left;i<rects.right;i++)
		   {
			   for (j=rects.bottom;j<rects.top;j++)
			   {
				   COLTMP	=  Get_Inter_Color(i-Showd_PX,j-Showd_PY,K1,K2,K3,K4,m_indate, m_Pitchin);
				   MIX_multself1( (m_outdate+4*i+m_PitchOut*j) , COLTMP);
				   
			   }
		   }
		   break;
	   case BLEND_ADD:
		   for (i=rects.left;i<rects.right;i++)
		   {
			   for (j=rects.bottom;j<rects.top;j++)
			   {
				   COLTMP	=  Get_Inter_Color(i-Showd_PX,j-Showd_PY,K1,K2,K3,K4,m_indate, m_Pitchin);
				   MIX_ADDself1( (m_outdate+4*i+m_PitchOut*j) , COLTMP);
				   
			   }
		   }
		   break;
		   
	   case BLEND_ONE:
		   for (i=rects.left;i<rects.right;i++)
		   {
			   for (j=rects.bottom;j<rects.top;j++)
			   {
				   COLTMP	=  Get_Inter_Color(i-Showd_PX,j-Showd_PY,K1,K2,K3,K4,m_indate, m_Pitchin);
				   MIX_ONEself1( (m_outdate+4*i+m_PitchOut*j) , COLTMP);
				   
			   }
		   }
		   break;
  
	   } 

};

////////////////////////////////////////

void GDIPIC::ProssVeroll( float force ,INT W , INT H)
{
  DWORD COLTMP;
  DWORD STARCOLOR=0X2020FF,ENDCOLOR=0X00FFFFFF,BLANKCOLOR=0X000000;
    float  k;
   	int j,i;
 	 force=Max(force,0.0f);
	 force=Min(force,(float)W);

  		   for (i=0;i<force;i++)
		   {
			 k=(float)i/force;
			 COLTMP=LEAPCOLOR((BYTE*)&STARCOLOR,(BYTE*)&ENDCOLOR,k); 
   		   for (j=0;j<H;j++)
		   {
			   
			 (*(DWORD*)(m_indate+4*i+m_Pitchin*j))=COLTMP; 
			 // *(m_indate+4*i+m_Pitchin*j)=0;
		   }
 		   }

  		   for (i=force;i<W;i++)
		   {
   		   for (j=0;j<H;j++)
		   {
			 (*(DWORD*)(m_indate+4*i+m_Pitchin*j))=BLANKCOLOR; 
		   }
 		   }

}

void GDIPIC::Sha_RotPic(Vector3 Pos ,float angle ,float W ,float H,float offsx,float offsy,RECT *trimrect )
{
 	   //���ñ߽�
		if(trimrect)
		{
			m_trimrect=*trimrect;
		}
		else
		{
			m_trimrect.left=1;
			m_trimrect.right=TABLE_WIDTH-1;
			m_trimrect.bottom=1;
			m_trimrect.top=TABLE_HEIGHT-1;
		}

Pos+=RotateZ(Vector3(0, 1), angle)*offsy;
Pos+=RotateZ(Vector3(1,0 ), angle)*offsx;

 Shader_RotatePic(Pos , angle , W , H );
}

//����ɨβ
void GDIPIC::Shader_Broom(Vector3 Pos ,float angle ,float W)
{
  b_useBroom=true;

   Bro_W=W;
 Bro_SL=Bro_W/12;
 Bro_S2=5;
 Bro_S1=Bro_SL-Bro_S2;
 Bro_Hhalf=17.5f;

  Bro_timeich+=(Bro_SL/5);
  if (Bro_timeich> Bro_SL)Bro_timeich-=Bro_SL;

   // Pos+=RotateZ(Vector3(0, 1), angle)*-17.5f;
   Shader_RotatePic	(Pos,angle,W,35,-17.5f);

   b_useBroom=false;
}

//������תͼ��
void GDIPIC::Shader_RotatePic(Vector3 Pos ,float angle ,float W ,float H,float DOFFY )
{

    angle = angle - (int)(angle / TWO_PI) * TWO_PI;
	if (angle <0)angle =TWO_PI+angle;

    asin = sinf(angle);
    acos = cosf(angle);
	
    RPIC_W = W;   RPIC_H = H;
    PntX = Pos.X;    PntY = Pos.Y;

	
	Vector3  P1,P2,P3,P4;
    Vector3 Low_X  , UP_X  , Low_Y  , UP_Y ; 
	float Xtmp1  , Xtmp2;
	
    P1 = Pos+ RotateZ(Vector3(W, H+DOFFY), angle);
    P2 = Pos+ RotateZ(Vector3(W, DOFFY), angle) ;
    P3 = Pos+ RotateZ(Vector3(0, DOFFY), angle);
    P4 = Pos+ RotateZ(Vector3(0, H+DOFFY), angle);
	
    if ((angle >= 0) && (angle < PI_DIV2))
	{ Low_X = P4; UP_X = P2; Low_Y = P3; UP_Y = P1;}
	
    else if ((angle >= PI_DIV2) && (angle < PI)) 
	{Low_X = P1; UP_X = P3; Low_Y = P4; UP_Y = P2;}
	
    else if ((angle >= PI) && (angle < PI_DIV2 * 3))
	{ Low_X = P2; UP_X = P4; Low_Y = P1; UP_Y = P3;	}
	
    else if ((angle >= PI_DIV2*3) &&(angle < TWO_PI)) 
	{Low_X = P3; UP_X = P1; Low_Y = P2; UP_Y = P4 ;	}
    
	
    if (UP_X.Y < Low_X.Y)
	{
		Xtmp1 = GET_ISTLINE_X(UP_X.X, UP_Y.X, UP_X.Y, UP_Y.Y, Low_X.Y);
        Xtmp2 = GET_ISTLINE_X(Low_Y.X, Low_X.X, Low_Y.Y, Low_X.Y, UP_X.Y);
		
        FILLTRI (Low_X.X, UP_Y.X, Xtmp1, UP_Y.X, Low_X.Y, UP_Y.Y);
        FILLTRI (Xtmp2, Low_X.X, UP_X.X, Xtmp1, UP_X.Y, Low_X.Y);
        FILLTRI (Low_Y.X, Xtmp2, Low_Y.X, UP_X.X, Low_Y.Y, UP_X.Y);
	}
    else
	{
        Xtmp1 = GET_ISTLINE_X(Low_X.X, UP_Y.X, Low_X.Y, UP_Y.Y, UP_X.Y);
        Xtmp2 = GET_ISTLINE_X(Low_Y.X, UP_X.X, Low_Y.Y, UP_X.Y, Low_X.Y);
		
        FILLTRI (Xtmp1, UP_Y.X, UP_X.X, UP_Y.X, UP_X.Y, UP_Y.Y);
        FILLTRI (Low_X.X, Xtmp1, Xtmp2, UP_X.X, Low_X.Y, UP_X.Y);
        FILLTRI (Low_Y.X, Low_X.X, Low_Y.X, Xtmp2, Low_Y.Y, Low_X.Y);
		
    }
	
};

//���һ����������
void  GDIPIC:: FILLTRI (float X1 ,float X2 ,float X3 ,float X4 ,float Y1 ,float Y2 )
{
	float Xtmp , Ytmp , Xtmp1 , Xtmp2 ;

  //�߽����						
  //		X2 _________Y2__________X4
  //		/						\
  //	   /						 \
  //	  /							  \
  //	 /							   \
  //    /_______________________________\
  //	X1				Y1				 X3
  // 
 
  //		                _________
  //	 __trimrect.top____/_________\___________
  //     | 	     		  /    1	  \			|
  //     |			     /_____________\	    |
  //	 |										|
  //trimrect.left							trimrect.right
  //   __|______	  						____|____
  //  /	 |	    \	  					   /	|	 \
  // /	 |4      \	  					  /	  3 |	  \ 
  ///____|________\	  					 /______|______\	
  //     |										|
  //     |										|
  //     |  			       _________			|
  //     |__trimrect.bottom___/_________\_______|
  //	  				     /    2	     \				 
  //	  			        /_____________\			     
  //


	//��ȫ������,��,��,�ұ߿��ⲿ
    if (abs(Y2 - Y1) < 0.0001) 
		return;

    if  ((Y1 > m_trimrect.top) || (Y2 < m_trimrect.bottom) || ((X3 < m_trimrect.left) && (X4 < m_trimrect.left)) ||((X1 > m_trimrect.right) && (X2 > m_trimrect.right)))
        return;
  
  	//1���ϱ߿����
    if (Y2 > m_trimrect.top)  
	{ Xtmp1 = GET_ISTLINE_X(X1, X2, Y1, Y2, m_trimrect.top);
       Xtmp2 = GET_ISTLINE_X(X3, X4, Y1, Y2, m_trimrect.top);
       FILLTRI (X1, Xtmp1, X3, Xtmp2, Y1, m_trimrect.top);
       return;
    }

  	//2���±߿����	
    if (Y1 < m_trimrect.bottom) 
	{  Xtmp1 = GET_ISTLINE_X(X1, X2, Y1, Y2, m_trimrect.bottom);
        Xtmp2 = GET_ISTLINE_X(X3, X4, Y1, Y2, m_trimrect.bottom);
        FILLTRI (Xtmp1, X2, Xtmp2, X4, m_trimrect.bottom, Y2);
        return;
    }
   
  	
  	//3�ұ߿�֮�����
    if ((X2 < m_trimrect.right) && (X4 > m_trimrect.right) && (X1 < m_trimrect.right) && (X3 > m_trimrect.right))  
	{ 
	FILLTRI (X1, X2, m_trimrect.right, m_trimrect.right, Y1, Y2);
	return;
	}
  
	//4��߿�֮�����								
    if ((X2 < m_trimrect.left) && (X4 > m_trimrect.left) && (X1 < m_trimrect.left) && (X3 > m_trimrect.left))  
	{
		FILLTRI (m_trimrect.left, m_trimrect.left, X3, X4, Y1, Y2);
		return;
	}

  //	     				 
  //          	   _____________________________________
  //               | ________	  						| ________
  //               |/        \	  				   		|/        \
  //               /	 7     \	  			  	    /	6      \
  //              /____________\	  				   /____________\	
  //               |									|
  //               |								    |
  //       _______ |	     			        _______ |			
  //      /       \|      				       /       \|
  //     /	  8     \         		 	      /	   5    \
  //    /___________\                        /___________\		
  //               | ___________________________________|
  //     	  						 

	//5�ұ��߶����ұ߿����
    if ((X4 - m_trimrect.right) * (X3 - m_trimrect.right) < 0) 
	{
		Ytmp = GET_ISTLINE_Y(X3, X4, Y1, Y2, m_trimrect.right);
        Xtmp = GET_ISTLINE_X(X1, X2, Y1, Y2, Ytmp);
        if (X4 < m_trimrect.right)
		{ 
			FILLTRI (Xtmp, X2, m_trimrect.right, X4, Ytmp, Y2);
            FILLTRI (X1, Xtmp, m_trimrect.right, m_trimrect.right, Y1, Ytmp);
        }
		else
		{  
			FILLTRI (Xtmp, X2, m_trimrect.right, m_trimrect.right, Ytmp, Y2);
            FILLTRI (X1, Xtmp, X3, m_trimrect.right, Y1, Ytmp);
        }
        return;
    }

	 //6����߶����ұ߿����
    if ((X1 - m_trimrect.right) * (X2 - m_trimrect.right) < 0)  
	{
		Ytmp = GET_ISTLINE_Y(X1, X2, Y1, Y2, m_trimrect.right);

        if (X1 < m_trimrect.right)
            FILLTRI (X1, m_trimrect.right, m_trimrect.right, m_trimrect.right, Y1, Ytmp);
        else
            FILLTRI (m_trimrect.right, X2, m_trimrect.right, m_trimrect.right, Ytmp, Y2);
       
        return;
	}

	  //7����߶�����߿����  /////////////////
    if ((X1 -m_trimrect.left) * (X2 - m_trimrect.left) < 0) 
	{  Ytmp = GET_ISTLINE_Y(X1, X2, Y1, Y2, m_trimrect.left)	;
        Xtmp = GET_ISTLINE_X(X3, X4, Y1, Y2, Ytmp);
        if (X1 < m_trimrect.left)
		{  
			FILLTRI (m_trimrect.left, X2, Xtmp, X4, Ytmp, Y2);
            FILLTRI (m_trimrect.left, m_trimrect.left, X3, Xtmp, Y1, Ytmp);
        }
		else
		{  
			FILLTRI (m_trimrect.left, m_trimrect.left, Xtmp, X4, Ytmp, Y2);
            FILLTRI (X1, m_trimrect.left, X3, Xtmp, Y1, Ytmp);
	}

        return;
    }

	 //8�ұ��߶�����߿����
    if (((X3 - m_trimrect.left) * (X4 -m_trimrect.left)) < 0)  
	{  
		Ytmp = GET_ISTLINE_Y(X3, X4, Y1, Y2, m_trimrect.left);
        if (X3 > m_trimrect.left)
            FILLTRI (m_trimrect.left, m_trimrect.left, X3, m_trimrect.left, Y1, Ytmp);
        else
            FILLTRI (m_trimrect.left, m_trimrect.left,m_trimrect.left, X4, Ytmp, Y2);
        
        return;
	}
	   

//
////////////////////////////////////////////////////////////	
	int i,j;
	float K1, K2;
    int LX , RX ;
    K1 = (X2 - X1) / (Y2 - Y1);
    K2 = (X4 - X3) / (Y2 - Y1);

if(b_useBroom==false)
{
for (j=Y1;j<=Y2;j++)
	{
		LX = K1 * (j - Y1) + X1;
        RX = K2 * (j - Y1) + X3	;
		for (i=LX;i<=RX;i++)
		{
				draw_pnt((int)i, (int)j) ;
		}
		
	}

}

////////////////////////////////////////////
//����ɨβ			  
//_______________________________________________________
//    \     \   \     \   \     \   \     \   \     \
//     \     \   \     \   \     \   \     \   \     \
//      \NUM1 \   \NUM2 \   \NUM3 \   \NUM4 \   \NUM5 \
//      /     /   /     /   /     /   /     /   /     /
//     /     /   /     /   /     /   /     /   /     /
// ___/_____/___/_____/___/_____/___/_____/___/_____/____
// 	  |-S1-|-S2-|	 	  
// 	  |----SL---|			 W
// 						 

else//if(b_useBroom==false)	
{
 float PX, PY;
 
 INT NUM;
 float cx,vel;
 SHORT C ;
 BYTE*P ;
 


 
 for (j=(INT)Y1;j<(INT)Y2;j++)
	{
		LX = K1 * (j - Y1) + X1;
        RX = K2 * (j - Y1) + X3	;
		for (i=LX;i<=RX;i++)
		{
		 PX = (i - PntX) * acos + (j - PntY) * asin;
         PY = -(i - PntX) * asin + (j - PntY) * acos;

		 if(PY>0)
			 vel=(PX+PY);
		 else
			 vel=(PX-PY);

		  if	(vel <26) continue;

		  vel-=Bro_timeich;

		 NUM= (int)(vel/Bro_SL);
		 if	(NUM >10) continue;

		 cx=vel-NUM*Bro_SL;
		  

		if(cx<Bro_S1)
		{ 
			 C=NUM*10+150;
			 // C=211;
			//C=cx/S1*255;
			//C=(PX-NUM*SL)/S1*255;
			P=(m_outdate+(int)i*4+(int)j*m_PitchOut);
			MIX_APLONEself(P,C);
			 
		  }
	
		}
		
	}

}

//////////////////////////////////////	
}


//���Ʋ�����
void  inline GDIPIC::draw_pnt(int X , int Y)
{

	float PX, PY ;
    DWORD C ;
	BYTE*P ;
    PX = (X - PntX) * acos + (Y - PntY) * asin;
    PY = -(X - PntX) * asin + (Y - PntY) * acos;
    if ((PX >= 0)&& (PX < RPIC_W-1)&& (PY >= 0)&& (PY < RPIC_H-1))
	{
		
		GetFitColor(PX, PY,m_indate,m_Pitchin,(BYTE*)&C);
		P= (m_outdate+X*4+Y*m_PitchOut);
		// *(DWORD*)P = C;
		MIX_APL((BYTE*)&C,P);
		
	} 
    else
	{
	}//// '        g_Backgoutex(X, Y).Red = 245
	
}



float  GDIPIC::GET_ISTLINE_X (float X1 ,float X2 ,float Y1 ,float Y2 ,float Y_in)
{
	float k;
    k = (X2 - X1) / (Y2 - Y1);
    return (k * (Y_in - Y1) + X1);
}


float  GDIPIC::GET_ISTLINE_Y (float X1 ,float X2 ,float Y1 ,float Y2 ,float X_in)
{
	float k;
    k = (Y2 - Y1) / (X2 - X1);
    return (k * (X_in - X1) + Y1);
}



void  GDIPIC::DRAWline(HDC hdc,int x1,int y1,int x2,int y2)
{	
 // 	HPEN   hpen   =   CreatePen(PS_SOLID,1,RGB(0,0,255));
SelectObject(hdc,  GetStockObject(WHITE_PEN)); 
  MoveToEx(hdc,   x1, BACK_HEIGHT-  y1,   NULL);   
  LineTo(hdc,  x2, BACK_HEIGHT- y2); 

}

// HPEN hPen;
// hPen= (HPEN)SelectObject(hdc,  GetStockObject(WHITE_PEN)); 
//  MoveToEx(hdc,   x1, BACK_HEIGHT-  y1,   NULL);   
//  LineTo(hdc,  x2, BACK_HEIGHT- y2); 
// SelectObject(hdc,hPen);

void  GDIPIC::DRAWEllipse(HDC hdc,int x1,int y1,int R)
{

	
  HPEN hPen;
 hPen= (HPEN)SelectObject(hdc,   GetStockObject(HOLLOW_BRUSH));
	Ellipse	(hdc,x1+R,BACK_HEIGHT-(y1-R),x1-R,BACK_HEIGHT-(y1+R));
 SelectObject(hdc,hPen);
	
}
