#if !defined(AFX_GDI_PROCESS_H)
#define AFX_GDI_PROCESS_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



extern  __inline void GetFitColor(float X, float Y ,BYTE *indate,int mPitch,BYTE *outdate);

extern __inline void   MIX_ADDself1 (BYTE *indate,int COL )	;

extern __inline void   MIX_ONEself1 (BYTE *indate,int COL );

extern __inline void  MIX_multself1 (BYTE *indate,int COL )	;

// extern __inline void  MIX_mult (BYTE *indate,int COL )  ;

extern  __inline void  MIX_APLC (BYTE *C1,BYTE *C2,SHORT NUMMIX  );

extern  __inline void   MIX_APL(BYTE *C1,BYTE *C2) ;

extern  __inline void   MIX_APLONEself(BYTE *C1,SHORT NUMMIX)  ;

extern __inline int Get_Inter_Color(int X, int Y ,FLOAT K1,FLOAT K2,FLOAT K3,FLOAT K4,BYTE *indate,int mPitch);

extern  __inline DWORD LEAPCOLOR(BYTE *C1,BYTE *C2,float k) ;

#endif