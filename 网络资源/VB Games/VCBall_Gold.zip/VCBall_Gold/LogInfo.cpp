#include "stdafx.h"
#include "LogInfo.h"
#include "MISC.H"
#include "physics.h"
#include "GDIPIC.h"

#include <mmsystem.h>
#pragma comment(lib,"winmm.lib")


extern  physics g_phy;
extern  GDIPIC	  gdipic ;

#ifdef _DEBUG
#endif

static bool m_fEnableLogging= 0;


/////////////////////////////////////////
LARGE_INTEGER m_liPerfFreq={0};
LARGE_INTEGER m_liPerfStart={0};
LARGE_INTEGER liPerfNow={0};
float stime[40000];
INT NUMstime=0;

void QUERYSTART()
{
	if(!m_fEnableLogging)return;
	
    QueryPerformanceFrequency(&m_liPerfFreq); 
    QueryPerformanceCounter(&m_liPerfStart);
}


void  QUERYEND(LPCTSTR lpszName)
{	
	if(!m_fEnableLogging)return;
	
    QueryPerformanceCounter(&liPerfNow);
	
    float usetime=( ( (float)(liPerfNow.QuadPart - m_liPerfStart.QuadPart) * 1000)/(float)m_liPerfFreq.QuadPart);
	
	if(NUMstime<40000)
	{	stime[NUMstime]=usetime;
	NUMstime++;	}
	
	TCHAR buffer[100];
	sprintf(buffer,"QueryPer %f",usetime);// "%f"��wsprintf()��Ч
	if(lpszName) strcat(buffer, lpszName);
	LogInfo(buffer) ;
	
}
////////////////////////////////////////////


void  LogInfos(HDC hdc)
{
	int i;
	for (i=0;i<NUMWALL;i++)
	{
		physics::cline &tWALL=g_phy.WALL[i];
		
		gdipic.DRAWline(hdc,tWALL.starpnt.X,tWALL.starpnt.Y,tWALL.endpnt.X,tWALL.endpnt.Y);
		
	}
	
	for (i=0;i<NUMPING;i++)
	{
		gdipic.DRAWEllipse(hdc,g_phy.Ping[i].pnt.X,g_phy.Ping[i].pnt.Y,g_phy.Ping[i].R);
	}
	
	
	for (i=0;i<NUMHOLE;i++)
	{
		gdipic.DRAWEllipse(hdc,g_phy.Hole[i].pnt.X,g_phy.Hole[i].pnt.Y,g_phy.Hole[i].R);
	}
	
};


void TRACE( LPCTSTR pszFormat, ... )
{
	if(!m_fEnableLogging)return;
	
    char buf[512]; 
    va_list argList; 
    va_start(argList, pszFormat );
    vsprintf( buf, pszFormat, argList );
    va_end(argList);
    OutputDebugString( buf ); 
} 



void StartLogging()
{
	if(!m_fEnableLogging)return;
	
	FILE* pFile=NULL;
	//Opens an empty file for writing.If the given file exists, its contents are destroyed.
    pFile=fopen("Log.htm","w");
	
	if(pFile!=NULL)
	{
		fprintf(pFile,"<html><head><title>Log File</title></head><body>\n");
		fprintf(pFile,"<font face=\"Arial\" size=\"4\" color=\"#000000\"><b><u>Log File</u></b></font><br>\n");
		
		fclose(pFile);
		// 	m_fEnableLogging=TRUE;
	}
}

void StopLogging()
{
	
	float Totoltime=0;
	  	int i;
		for (i=0;i<NUMstime;i++)
		{
			Totoltime+=stime[i];
		}
		Totoltime/=NUMstime;
		
		TCHAR buffer[100];
		sprintf(buffer,"Totoltime:%f     NUMstime:%ld",Totoltime,NUMstime);// "%f"��wsprintf()��Ч
		LogInfo(buffer) ;
		
		
		
		
		if(m_fEnableLogging)
		{
			FILE *pFile=NULL;
			
			//Opens for reading and appending
			pFile=fopen("Log.htm","a+");
			
			if(pFile!=NULL)
			{
				fprintf(pFile,"</body></html>");
				fclose(pFile);
			}
			m_fEnableLogging=FALSE;
		}
}	     


void LogError(char *lpszText,...)
{
	if(m_fEnableLogging)
	{
		va_list argList;
		FILE *pFile=NULL;
		
		//Initialize variable argument list
		va_start(argList,lpszText);
		
		//Open the log file for appending
		pFile=fopen("Log.htm","a+");
		
		if(pFile!=NULL)
		{
			//Write the error to the log file
			fprintf(pFile,"<font face=\"Arial\" size=\"3\" color=\"#FF0000\"><b>");
			vfprintf(pFile,lpszText,argList);
			fprintf(pFile,"</b></font><br>\n");
			
			fclose(pFile);
		}
		va_end(argList);
	}
}

void LogInfo(char *lpszText,...)
{
	if(m_fEnableLogging)
	{
		va_list argList;
		FILE *pFile=NULL;
		
		//Initialize variable argument list
		va_start(argList,lpszText);
		
		//Open the log file for appending
		pFile=fopen("Log.htm","a+");
		
		if(pFile!=NULL)
		{
			//Write the Info to the log file
			fprintf(pFile,"<font face=\"Arial\" size=\"3\" color=\"#000000\"><b>");
			vfprintf(pFile,lpszText,argList);
			fprintf(pFile,"</font></b><br>\n");
			
			fclose(pFile);
		}
		va_end(argList);
	}
}




void PlayWav( LPCTSTR lpszName, DWORD fdwSounds)
{
	PlaySound(lpszName, NULL, fdwSounds);
}