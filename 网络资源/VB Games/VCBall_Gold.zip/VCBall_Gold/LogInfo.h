extern  void  LogInfos(HDC hdc);
extern    void TRACE( LPCTSTR pszFormat, ... ) ;

  	extern void StartLogging();
 extern void StopLogging();
	extern void LogError(char *lpszText,...);
	extern void LogInfo(char *lpszText,...);
	extern void LogWarning(char *lpszText,...);
	extern  void PlayWav( LPCTSTR lpszName, DWORD fdwSounds=SND_ASYNC);

	extern	void QUERYSTART(); // ���ܲ���ʼ


	extern void  QUERYEND(LPCTSTR lpszName=0);	// ���ܲ���ĩ
