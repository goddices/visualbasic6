// Tpgl.h: interface for the Tpgl class.
//
//////////////////////////////////////////////////////////////////////
//ͼƬ������

#if !defined(TPGL_H)
#define TPGL_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



class Tpgl  
{
public:
	Tpgl();
	virtual ~Tpgl();
	void Tpgl::CreateBlank( float w,float h);
	 void Tpgl::Copy_FormOther( Tpgl &Tp);
	void LoadImage( LPCTSTR lpszName, bool gray=0);
	void LoadApl( LPCTSTR lpszName)	;

	 void convergray () ;
 	BITMAPINFOHEADER bih;

private:
	

public:
	 void Hz(HDC hDC,int Xpos,int Ypos);

	void Hz2(HDC hDC,int Xpos,int Ypos);
	int m_nWidth;
	int m_nHeight;
	int m_nPitch;
	BYTE *m_pBits;
	
};

#endif // !defined(AFX_TPGL_H__64027DBC_8B1F_4DFF_A6DC_DC6B14A07AE0__INCLUDED_)
