#include "stdafx.h"
#include "physics.h"
#include "MISC.H"
#include "LogInfo.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// ball_shuju ballsj[1];//1���������

const float  Elasticity_BallToBall = 0.8f;  //������֮��ķ���ϵ��
const float  Elasticity_BallToWall = 0.7f;  //ǽ����ķ���ϵ��

const float  Per_Friction_BallToBall = 0.4f;	 //����� ˲��ײ����Ħ��ϵ�� 
const float  Per_Friction_BallToWall = 0.5f;    //ǽ���� ˲��ײ����Ħ��ϵ�� 


physics::physics()
{
	// #define TABLE_WIDTH  800
	
	int i;
	
	FLOAT PT[][2]={{34.04f,0},{76.77f,42.73f},{89.5f,BAR_WIDTH},{354.5,BAR_WIDTH},{TABLE_WIDTH-89.5f,BAR_WIDTH},{TABLE_WIDTH-354.5,BAR_WIDTH},{TABLE_WIDTH-34.04f,0},{TABLE_WIDTH-76.77f,42.73f}
	,{TABLE_WIDTH-0,34.04f},{TABLE_WIDTH-42.73f,76.77f} ,{TABLE_WIDTH-BAR_WIDTH,89.5f},{TABLE_WIDTH-BAR_WIDTH,TABLE_HEIGHT-89.5f},{TABLE_WIDTH-0,TABLE_HEIGHT-34.04f},{TABLE_WIDTH-42.73f,TABLE_HEIGHT-76.77f}
	, {TABLE_WIDTH-34.04f,TABLE_HEIGHT-0},{TABLE_WIDTH-76.77f,TABLE_HEIGHT-42.73f} ,{TABLE_WIDTH-89.5f,TABLE_HEIGHT-BAR_WIDTH},{TABLE_WIDTH-354.5,TABLE_HEIGHT-BAR_WIDTH} ,{89.5f,TABLE_HEIGHT-BAR_WIDTH},{354.5,TABLE_HEIGHT-BAR_WIDTH},{34.04f,TABLE_HEIGHT-0},{76.77f,TABLE_HEIGHT-42.73f}
	,{0,TABLE_HEIGHT-34.04f},{42.73f,TABLE_HEIGHT-76.77f},{BAR_WIDTH,89.5f},{BAR_WIDTH,TABLE_HEIGHT-89.5f}	,{0,34.04f},{42.73f,76.77f}
	
	};
	for (i=0;i<NUMWALL;i++)
	{
		cline& tWALL= WALL[i];
		tWALL.starpnt=Vector3(PT[i*2][0],PT[i*2][1] );
		tWALL.endpnt=Vector3(PT[i*2+1][0],PT[i*2+1][1]);
		tWALL.Nor=RotateZ(NormaliseVector(tWALL.starpnt-tWALL.endpnt), PI_DIV2);
		tWALL.d = dot(tWALL.starpnt, tWALL.Nor) ;
	}
	
	//Բת�Ǵ�
	//  10      9  8   	    7
	// 11      				 6
	// 
	//	
	//
	// 12			         5
	//  1       2  3        4
	FLOAT PT2[][2]={{89.5,30},{354.5,30},{TABLE_WIDTH-354.5,30},{TABLE_WIDTH-89.5,30}
	,{TABLE_WIDTH-30,89.5},{TABLE_WIDTH-30,TABLE_HEIGHT-89.5}
	,{TABLE_WIDTH-89.5,TABLE_HEIGHT-30},{TABLE_WIDTH-354.5,TABLE_HEIGHT-30},{354.5,TABLE_HEIGHT-30},{89.5,TABLE_HEIGHT-30}
	,{30,TABLE_HEIGHT-89.5},{30,89.5}};
	
	for (i=0;i<NUMPING;i++)
	{
		Ping[i].pnt=Vector3(PT2[i][0],PT2[i][1] );
		Ping[i].R=18;
	}
	
	
	/////////////////////////////////////////////////////
	//6���Ŷ�  
	FLOAT PT3[][2]={{40,40},{TABLE_WIDTH/2,27},{TABLE_WIDTH-40,40}
	,{TABLE_WIDTH-40,TABLE_HEIGHT-40},{TABLE_WIDTH/2,TABLE_HEIGHT-27},{40,TABLE_HEIGHT-40}} ;
	for (i=0;i<NUMPING;i++)
	{
		Hole[i].pnt=Vector3(PT3[i][0],PT3[i][1] );
		Hole[i].R=22;
	}
	
	
	
	
}

physics::~physics()
{
	
}


void physics:: Allcollision(CBALL*p_BALL)
{	
	// p_BALL->Pos=Vector3	(40,40);
	Vector3 pos1 , pos2	, Vtra ;
	float	Extra ;
	int i,j;
	
	//������֮�����ײ
	for (i=0;i<NUM_BALL-1;i++)
	{	
		if (p_BALL[i].bEnable==false)continue;
		pos1 = p_BALL[i].Pos;

		for (j=(i+1);j<NUM_BALL;j++)
		{

		if (p_BALL[j].bEnable==false)continue;
		 if ((p_BALL[i].State==4)&&(p_BALL[j].State==4))continue;

			pos2 = (*(p_BALL+j)).Pos;
			Vtra = (pos1- pos2)	;
			
			Extra = Vtra.mag() - (banjin + banjin);
            if (Extra < 0)
			{

				if(process_collision ((p_BALL+i), (p_BALL+j), (pos1+ pos2)/2, NormaliseVector(Vtra), -Extra))
				PlayWav("ballHITball.wav");//ײ��

			}
			
		}
	}
	
	
	collision_wall(p_BALL);
	collision_hole(p_BALL);
} //END physics:: Allcollision(CBALL*p_BALL)

//������Ƿ����
void physics::collision_hole(CBALL*p_BALL)
{
	Vector3 pos1,  Vtra ;
	float	Extra ;
	int i,j;
	
	for (i=0;i<NUM_BALL;i++)
	{ 
		if (p_BALL[i].bEnable==false)continue;
		 pos1 = p_BALL[i].Pos;
		for (j=0;j<NUMHOLE;j++)
		{ 
			Vtra = (pos1-Hole[j].pnt) ;

			//�����Ľ��붴��,ʩ��һ��ʹ�����п�£
			Extra = Vtra.mag()- Hole[j].R ;
			if (Extra < 0)
			p_BALL[i].V-=(NormaliseVector(Vtra)/1000);


			//����ȫ���붴��
			Extra = Vtra.mag() + p_BALL[i].Rbou - Hole[j].R ;
			if (Extra < 0) 
			{
				p_BALL[i].binhole=true;
				p_BALL[i].bEnable=false;
				// p_BALL[i].Pos=Vector3(0);
				p_BALL[i].V=Vector3(0);
				p_BALL[i].Vang=Vector3(0);
				p_BALL[i].State=4;
				 PlayWav("stopcue.wav");//����
            }
		}
	}
	

	

	//��ֹԽ��
	for (i=0;i<NUM_BALL;i++)
	{
		if (p_BALL[i].bEnable==false)continue;
		 pos1 = (*(p_BALL+i)).Pos;

		 if ((pos1.Y<27)||(pos1.Y>TABLE_HEIGHT-27)||(pos1.X<27)||(pos1.X>TABLE_WIDTH-27))
		 {
		  		p_BALL[i].binhole=true;
				p_BALL[i].bEnable=false;
				p_BALL[i].V=Vector3(0);
				p_BALL[i].Vang=Vector3(0);
				p_BALL[i].State=4;
				PlayWav("stopcue.wav");//����
		 }
		}
	
}

void physics::collision_wall(CBALL*p_BALL)
{
	Vector3 pos1 ,  Vtra ;
	float	Extra ;
	int i,j;
	
	Vector3 CZ ; //��ֱ��
	float k ; //��ֱ�� 
	
	//��ǽ�����ײ
   	for (i=0;i<NUM_BALL;i++)
	{ 
		if (p_BALL[i].State==4)continue;
		for (j=0;j<NUMWALL;j++)
		{ 
			
            pos1 = (*(p_BALL+i)).Pos;
            Extra = dot(pos1, WALL[j].Nor) - WALL[j].d ;
            
            if (abs(Extra) < (*(p_BALL+i)).Rbou) 
			{
				CZ = (pos1+ (WALL[j].Nor* -Extra));
				
				if (WALL[j].starpnt.X != WALL[j].endpnt.X) 
					k = (CZ.X - WALL[j].endpnt.X) / (WALL[j].starpnt.X - WALL[j].endpnt.X);
				else
					k = (CZ.Y - WALL[j].endpnt.Y) / (WALL[j].starpnt.Y - WALL[j].endpnt.Y) ;
				
				
				if ((k > 0) && (k < 1))
				{
					if (Extra > 0) 
						process_collision_wall( (p_BALL+i), (pos1 -(WALL[j].Nor*(*(p_BALL+i)).Rbou)), WALL[j].Nor, (*(p_BALL+i)).Rbou - Extra);
					else
						process_collision_wall( (p_BALL+i), (pos1 +(WALL[j].Nor*(*(p_BALL+i)).Rbou)), -WALL[j].Nor, (*(p_BALL+i)).Rbou + Extra);
					
				} //if k > 0 And k < 1 {
				
            }
			
		}
	}
	
	
	
	//	//��ǽ2�˵����ײ
	//	
	//   	for (i=0;i<NUM_BALL;i++)
	//	{ 
	//		for (j=0;j<3;j++)
	//		{ 
	//			
	//            pos1 = (*(p_BALL+i)).Pos;
	//			
	//			Vtra = (pos1- WALL[j].starpnt);
	//            Extra = Vtra.mag() - (*(p_BALL+i)).Rbou;
	//            if (Extra < 0)  process_collision_wall( (p_BALL+i), WALL[j].starpnt, NormaliseVector(Vtra), -Extra);
	//			
	//            Vtra = (pos1- WALL[j].endpnt);
	//            Extra = Vtra.mag() -  (*(p_BALL+i)).Rbou;
	//            if (Extra < 0)  process_collision_wall( (p_BALL+i), WALL[j].endpnt, NormaliseVector(Vtra), -Extra);
	//		}
	//	}
	
	//��Բ�߽ǵ���ײ
   	for (i=0;i<NUM_BALL;i++)
	{ 	 
		if (p_BALL[i].State==4)continue;
		for (j=0;j<NUMPING;j++)
		{ 
			pos1 = (*(p_BALL+i)).Pos;
            Vtra = (pos1- Ping[j].pnt) ;
            Extra = Vtra.mag() - ((*(p_BALL+i)).Rbou + Ping[j].R) ;
            if (Extra < 0) 
			{
				Vtra = NormaliseVector(Vtra);
                process_collision_wall ((p_BALL+i), (pos1+ (Vtra* -(*(p_BALL+i)).Rbou)), Vtra, -Extra )	;
            }
		}
		
	}
    
}


//ǽ�����ײ��
BOOL physics::process_collision_wall(CBALL* Boxa,Vector3 collpos ,Vector3 colN ,float Extra )
{
	
	//�̴�����
    Boxa->Pos+=(colN*Extra);
	
	collision cl;
    Vector3 posa, Vanga ,  Va ;
	
    posa = Boxa->Pos ; 
    Vanga = Boxa->Vang ;
    Va = Boxa->V;
	
    cl._N = colN;
    cl.Ra = (collpos- posa);
    cl.Va = (cross(Vanga, cl.Ra)+ Va);  //v'= v +�ء�R
    cl.Vn = dot(cl._N, cl.Va) ; //��Դ�ֱ�ٶ�
    cl.Vn2 = -Elasticity_BallToWall * cl.Vn; //��ֱ����ٶ�(��ײ��) Elasticity_BallToWall�Ƿ���ϵ��
    if (cl.Vn >= 0 ) return FALSE;
    cl.Ca = 1.0f / Boxa->M ;
	
    cl.Pn=cl._N * ((cl.Vn2 - cl.Vn) / cl.Ca );
	
	//Ӧ��������
    Boxa->applyimpulse(cl.Pn, collpos);  
	
	
    //��ʼĦ�������ļ���
    collision clnew; //�Ѿ��ı����ײ
	
    clnew._N = cl._N ;
    clnew.Ra = cl.Ra;
    clnew.Va = (cross(Vanga, clnew.Ra)+Va);  // v'= v +�ء�R
	
    clnew.tangent_vel = (clnew.Va- (clnew._N* dot(clnew.Va, clnew._N)));  //tangent_vel=Va+Vb-((Va+Vb)��N)*N
	
    clnew.tangent_speed = clnew.tangent_vel.mag();
    if (clnew.tangent_speed > 0)
	{
        Vector3 T ;
		T= -clnew.tangent_vel / clnew.tangent_speed ;
        //Ca = 1/m+((Ra��T)/Iz��Ra)T
        clnew.c = 1 / Boxa->M + dot(T, cross((cross(clnew.Ra, T) / Boxa->Iz), clnew.Ra)) ;
        
        if (clnew.c > 0 )
		{
			
            float Ptt;  //��ʱĦ������
            Ptt = clnew.tangent_speed / clnew.c;
			
            if (Ptt < Per_Friction_BallToWall * cl.Pn.mag())  //����Ħ���ж� Per_Friction_BallToWall��Ħ��ϵ��
				
                clnew.Pt = Ptt; //��Ħ��
            else
                clnew.Pt = Per_Friction_BallToWall * cl.Pn.mag(); //��Ħ��
			
            Boxa->applyimpulse (T* clnew.Pt, collpos);  //Ӧ��Ħ������
			
		} //end if (clnew.c > 0 )
		
	}  //end if (clnew.tangent_speed > 0)
	
PlayWav("ballHITBar.wav");//ײǽ
return TRUE ;	
}

//��ʼ�������ļ���
BOOL physics::process_collision(CBALL* Boxa,CBALL* Boxb,Vector3 collpos ,Vector3 colN ,float Extra )
{
	//�̴�����
    Boxa->Pos +=(colN*Extra * 0.5);
    Boxb->Pos +=(colN*-Extra * 0.5);
	
    collision cl;
    Vector3 posa, posb ,Vanga , Vangb, Va , Vb;
	
    posa = Boxa->Pos ; 	posb = Boxb->Pos; 
    Vanga = Boxa->Vang; Vangb =Boxb->Vang ;
    Va = Boxa->V; Vb = Boxb->V;
	
    cl._N = colN;
    cl.Ra = (collpos- posa);
    cl.Rb = (collpos- posb);
    cl.Va = (cross(Vanga, cl.Ra)+ Va);  //v'= v +�ء�R
    cl.Vb = (cross(Vangb, cl.Rb)+ Vb);
    cl.Vn = dot(cl._N, cl.Va) - dot(cl._N, cl.Vb); //��Դ�ֱ�ٶ�
    cl.Vn2 = -Elasticity_BallToBall* cl.Vn; //��ֱ����ٶ�(��ײ��) Elasticity_BallToBall�Ƿ���ϵ��
    if (cl.Vn >= 0 ) return FALSE;
    cl.Ca = 1.0f / Boxa->M ;
    cl.Cb = 1.0f / Boxb->M;
    cl.Pn=cl._N * ((cl.Vn2 - cl.Vn) / (cl.Ca + cl.Cb));
	
	//Ӧ��������
    Boxa->applyimpulse(cl.Pn, collpos);  
    Boxb->applyimpulse (-cl.Pn, collpos);
	
    //��ʼĦ�������ļ���
    collision clnew; //�Ѿ��ı����ײ
    Vector3 Vr_All ;
	
    clnew._N = cl._N ;
    clnew.Ra = cl.Ra; clnew.Rb = cl.Rb;
    clnew.Va = (cross(Vanga, clnew.Ra)+Va);  // v'= v +�ء�R
    clnew.Vb = (cross(Vangb, clnew.Rb)+Vb);
    Vr_All = (clnew.Va- clnew.Vb);
    clnew.tangent_vel = (Vr_All- (clnew._N* dot(Vr_All, clnew._N)));  //tangent_vel=Va+Vb-((Va+Vb)��N)*N
	
    clnew.tangent_speed = clnew.tangent_vel.mag();
    if (clnew.tangent_speed > 0)
	{
        Vector3 T ;
		T= -clnew.tangent_vel / clnew.tangent_speed ;
        //Ca = 1/m+((Ra��T)/Iz��Ra)T
        clnew.Ca = 1 / Boxa->M + dot(T, cross((cross(clnew.Ra, T) / Boxa->Iz), clnew.Ra)) ;
        clnew.Cb = 1 / Boxb->M + dot(T, cross((cross(clnew.Rb, T) / Boxb->Iz), clnew.Ra)) ;
        clnew.c = clnew.Ca + clnew.Cb ;
		
        if (clnew.c > 0 )
		{
            const float friction = Per_Friction_BallToBall; //��Ħ��ϵ��
            float Ptt;  //��ʱĦ������
            Ptt = clnew.tangent_speed / clnew.c;
			
            if (Ptt < friction * cl.Pn.mag())  //����Ħ���ж�
                clnew.Pt = Ptt; //��Ħ��
            else
                clnew.Pt = friction * cl.Pn.mag(); //��Ħ��
			
            Boxa->applyimpulse (T* clnew.Pt, collpos);  //Ӧ��Ħ������
            Boxb->applyimpulse (-T* clnew.Pt, collpos);
			
		} //end if (clnew.c > 0 )
		
	}  //end if (clnew.tangent_speed > 0)
	

return TRUE ;	
}	;

//
//��ײ���
//void physics::pzjc()
//{
//  
//	Matrix3 tmp;
//	
//}
