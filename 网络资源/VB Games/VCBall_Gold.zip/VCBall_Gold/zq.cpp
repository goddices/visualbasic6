// zq.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include "MISC.H"
#include "Tpgl.h"
#include "CBALL.h"
#include "physics.h"
#include "GDIBALL.h"
#include "GDIPIC.h"
#include "LogInfo.h"



char szMsg[] = "̨���㷨��ʾ";
 // #pragma comment( lib, "..\\debug\\libTest.lib" ) 
  //  ��һ��HTMLҳ�� ShellExecute(Handle, 'open', PChar('http://www.festra.com/'), nil, nil, SW_SHOW);
   // ��ʼһ���µ�Ӧ�ó��� ��ShellExecute(Handle, 'open', PChar('c:\test\app.exe'), nil, nil, SW_SHOW);



#define		STATE_BALLS_MOVE						1	 //̨�����״̬
#define		STATE_PLAYER_CONTROL_CUE				2	 //�û����״̬
#define		STATE_SET_GAN					3	 //�����Զ�������״̬

INT GAMEState=STATE_BALLS_MOVE;

// Global Variables:
HINSTANCE hInst;								// current instance
HWND hWnd;

bool swapgan( float &desten); //������
Vector3 hitSTATEimpulse;
Vector3 hitSTATEPnt;
float hitSTATEang;

VOID StarhitBall()	;
void SETVeroll	(float force);
void SEThitPoint(float Px, float Py);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
void				Init();
void				paint( HDC hdc);
bool inRect( float X,float Y, RECT &rects);

Tpgl g_Backgoutex;  //����
Tpgl g_Backgoutex_tmp; //����ͼƬ����

Tpgl g_Backgoutex_AT; 

Tpgl g_ball_tex;  //��
Tpgl g_ball_specular; //�߹�
Tpgl g_Shadow_tex;
Tpgl g_TEX_AT;
Tpgl g_TEX_AT2;
Tpgl g_Heading;	//����

Tpgl g_HitForceVeroll; //������
RECT ForceVerollrect={445,562,570,550};
BOOL BFORCE	=FALSE;
FLOAT hitforce=3;
FLOAT HIT_MUBX=0 ,HIT_MUBY=0 ;
Tpgl g_HitBall;
Tpgl  g_HitBall_tmp;


Tpgl g_HitMarker;	//������

GDIPIC	  gdipic ;
GDIBALL	  gdiball[NUM_BALL];
CBALL 	  balls[NUM_BALL];
physics g_phy;

DWORD farmecont=0;
//
//Tpgl tp_ball;
//Tpgl ballpic;
//Tpgl zm;
//qiou QT;
int CurMouseX,CurMouseY;
BOOL bwm_mousemove=0;
BOOL bwm_lbuttonup=0;
BOOL bwm_lbuttondown=0;

long fps;
FLOAT ATAng	;




void OnCreate(HWND hWnd)
{
	RECT rect={0,0,BACK_WIDTH,BACK_HEIGHT};
	AdjustWindowRect(&rect,WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,0);
	POINT lefttop;
	lefttop.x=(GetSystemMetrics(SM_CXSCREEN)-(rect.right-rect.left))/2;
	lefttop.y=(GetSystemMetrics(SM_CYSCREEN)-(rect.bottom-rect.top))/2;
	rect.left+=lefttop.x;
	rect.right+=lefttop.x;
	rect.top+=lefttop.y;
	rect.bottom+=lefttop.y;
	MoveWindow(hWnd,rect.left,rect.top,rect.right-rect.left,rect.bottom-rect.top,TRUE);
	StartLogging();
	
	  PlayWav(NULL,0x0040|0x0002);	//SND_PURGE 0x0040  SND_NODEFAULT 0x0002 

}	 

void Init()
{
#ifdef _DEBUG
	g_Backgoutex_tmp.LoadImage("TEX_Back_ground.bmp",true);
	g_Heading.LoadImage("TEX_Heading.bmp",true);
	g_HitMarker.LoadImage("TEX_HitMarker.bmp",true);
   	g_ball_tex.LoadImage("TEX_BALL1.bmp",true);
#else
 	g_Backgoutex_tmp.LoadImage("TEX_Back_ground.bmp");
	g_Heading.LoadImage("TEX_Heading.bmp");
	g_HitMarker.LoadImage("TEX_HitMarker.bmp");
		g_ball_tex.LoadImage("TEX_BALL1.bmp");
#endif	


	g_Backgoutex.Copy_FormOther(g_Backgoutex_tmp);
	

	g_ball_specular.LoadImage("TEX_Specular.bmp");
	g_Shadow_tex.LoadImage("TEX_Shadow.bmp");
	g_TEX_AT.LoadImage("AT.bmp");
	  	g_TEX_AT.LoadApl("ATAPL.bmp");

		
		
		g_HitBall_tmp.LoadImage("TEX_HitBall.bmp");
		g_HitBall.Copy_FormOther(g_HitBall_tmp);	
		g_HitForceVeroll.CreateBlank(130,14) ;
		

		const float yups =BALLDiameter*0.8660256f;  //*3BALLDIAMETER* _/-3/2

		// 	    	 15
		//  	 2
		//	  7	     13
		//	4	 6
		//1	  8	     11
		//	9	 5
		//	  3		 14
		//		 10	
		//			 12
		balls[0].Pos=Vector3(208,260) ;
		FLOAT bp8[][3]={{0,0,1},
		{yups,banjin,4},{yups,-banjin,9},
		{yups*2,banjin*2,7},{yups*2,0,8},{yups*2,-banjin*2,3}
		,{yups*3,banjin*3,2},{yups*3,banjin,6},{yups*3,-banjin,5},{yups*3,-banjin*3,10}
		,{yups*4,banjin*4,15},{yups*4,banjin*2,13},{yups*4,0,11},{yups*4,-banjin*2,14},{yups*4,-banjin*4,12}};

		int i;

		for (i=1;i<NUM_BALL;i++)
			balls[(int)bp8[i-1][2]].Pos=Vector3(bp8[i-1][0]+585,bp8[i-1][1]+TABLE_HEIGHT/2); 

		

		 //rand()����0��RAND_MAX֮��������ֵ��RAND_MAX������stdlib.h����ֵΪ2147483647
		  srand( GetTickCount());
			for (i=1;i<NUM_BALL;i++)
		{
			Vector3  ran=NormaliseVector(Vector3(ranged_random(.1f,2),ranged_random(.1f,2),ranged_random(.1f,2)));
		 balls[i].Orientation= rotation_matrix (ranged_random(1,800), ran);	// ����ÿ����������λ
		}
		  
		//  balls[7].applyimpulseSelf (Vector3(-0.f, 0.2f) );
		// balls[0].apply_torque (Vector3(0, 0, -25)	);

		  SETVeroll	(36);
		  SEThitPoint(0,0);
}


////////////////////////////////////////////////////
void paint( ){
	 char cc[40];
		 
	HDC hdc =GetDC(hWnd);
	int i;
	double t=GetTickCount();
	
	 // GetTickCount()��GetCurrentTime()��ֻ��ȷ��55ms(1��tick����55ms)�����Ҫ��ȷ�����룬Ӧ��ʹ��timeGetTime������QueryPerformanceCounter������
	if ((GetTickCount()-fps)>15) 
	{
		 farmecont++;
		fps=GetTickCount();
	
		//��������
		////////////////////////////////////////////////  /////////////////	   ///////////


	   	if(bwm_mousemove)
{				

					//��˽Ƕ�
					if(CurMouseY<TABLE_HEIGHT)g_phy.m_ang=User_Atn((FLOAT)(balls[0].Pos.X-CurMouseX),(FLOAT)(balls[0].Pos.Y-CurMouseY) );
					if(BFORCE==TRUE)
					{ 
						SETVeroll (CurMouseX-ForceVerollrect.left);
					}
}

		/////////////////////////////////////////////////////////////////////////////////////////
   	if(bwm_lbuttondown)
	{
	  		if (Vector3(CurMouseX-400 ,CurMouseY-555).mag()<22	)
		{
			
			 SEThitPoint((FLOAT)(CurMouseX-400) ,(FLOAT)(CurMouseY-555));
	
		}
		
		//���������� 
		if (inRect( CurMouseX,CurMouseY,ForceVerollrect))
		{
			BFORCE=TRUE;
			SETVeroll (CurMouseX-ForceVerollrect.left);

		}
		
		
		if( (GAMEState==STATE_PLAYER_CONTROL_CUE) &&( CurMouseY<TABLE_HEIGHT)) //�û������˴����
		{
		  StarhitBall();
		}

	}
		/////////////////////////////////////////////////////////////////////////////////////////

					if(bwm_lbuttonup)
					{
						BFORCE=FALSE;	
					}
	   /////////////////////////////////////////////////////////////////////////////////////////

		RECT rects={BAR_WIDTH,TABLE_HEIGHT-BAR_WIDTH ,TABLE_WIDTH-BAR_WIDTH,BAR_WIDTH};
		int size = g_Backgoutex.m_nHeight*g_Backgoutex.m_nPitch;
		memcpy(g_Backgoutex.m_pBits, g_Backgoutex_tmp.m_pBits, size);  //	�������

		//		 	Matrix3 M;
		//			  M = matrix3_identity();
		//			M =	 rotation_matrix(22.2f,Vector3(1.0f,0.1f,0.2f))	;
		

		//��ʼ������Ӱ
		
		Vector3  ShadPos;
		for (i=0;i<NUM_BALL;i++)
		{
			 if	(balls[i].bEnable==false) continue;		//��Ч������Ӱ����

			ShadPos=gdiball[i].Cale_ShadowPos(balls[i].Pos) ;
			gdipic.iniTex(g_Shadow_tex.m_pBits,g_Shadow_tex.m_nPitch,g_Backgoutex.m_pBits,g_Backgoutex.m_nPitch);
			gdipic.ShaderTEX(ShadPos.X,ShadPos.Y,g_Shadow_tex.m_nWidth,g_Shadow_tex.m_nHeight,BLEND_MULT,&rects) ;
		}
		
		
	// 	QUERYSTART();

				  
	
		Vector3  BPos;
		for (i=0;i<NUM_BALL;i++)
		{
			 if	(balls[i].bEnable==false) 
				 continue;	//��Ч����Ȼ���û�

			// ��ʼ��Ⱦ̨��	
			 BYTE *P=g_ball_tex.m_pBits+i*g_ball_tex.m_nHeight*4;
			gdiball[i].Shader_ball(balls[i].Orientation,balls[i].Pos,P,g_ball_tex.m_nPitch,g_Backgoutex.m_pBits,g_Backgoutex.m_nPitch);
			
			
			//���Ƹ߹�
			BPos=balls[i].Pos;
			gdipic.iniTex(g_ball_specular.m_pBits,g_ball_specular.m_nPitch,g_Backgoutex.m_pBits,g_Backgoutex.m_nPitch);
			gdipic.ShaderTEX(BPos.X ,BPos.Y,g_ball_specular.m_nWidth,g_ball_specular.m_nHeight,BLEND_ADD,NULL) ;
			
		}		 
		
		  // QUERYEND("��Ⱦ̨��");

	
		if( GAMEState==STATE_PLAYER_CONTROL_CUE)
		{
			//��ʼ�������
			gdipic.iniTex(g_TEX_AT.m_pBits,g_TEX_AT.m_nPitch,g_Backgoutex.m_pBits,g_Backgoutex.m_nPitch);
			gdipic.Sha_RotPic(balls[0].Pos,g_phy.m_ang,g_TEX_AT.m_nWidth,g_TEX_AT.m_nHeight,20,-g_TEX_AT.m_nHeight/2 );
			//����ɨβ
 gdipic.Shader_Broom(balls[0].Pos,g_phy.m_ang+PI,100+5*hitforce);
		}
		
		
		
		if( GAMEState==STATE_SET_GAN)
		{	  
		 float dest=0;
		if(swapgan( dest))
		{	
			balls[0].applyimpulse (hitSTATEimpulse, hitSTATEPnt) ;
			GAMEState=STATE_BALLS_MOVE;
			PlayWav("strikeball.wav");  //SND_ASYNC 0x0001 
		}
//		sprintf(cc,"dest:%4.4f",dest);
//		TextOut( hdc, 12, 70, cc, lstrlen(cc) );

			//��ʼ���Ƹ�
			gdipic.iniTex(g_TEX_AT.m_pBits,g_TEX_AT.m_nPitch,g_Backgoutex.m_pBits,g_Backgoutex.m_nPitch);
			gdipic.Sha_RotPic(balls[0].Pos,hitSTATEang,g_TEX_AT.m_nWidth,g_TEX_AT.m_nHeight,20+dest,-g_TEX_AT.m_nHeight/2 );
		}
		
		
		 g_Backgoutex.Hz(hdc,0,BACK_HEIGHT -TABLE_HEIGHT);//й¶����޹�
		 g_Heading.Hz(hdc,0,0); //й¶����޹�

		 //gdipic.DRAWline(hdc,20,20,200,300);
	  //gdipic.DRAWEllipse(hdc,120,120,30) ;
		
		






		
		#ifndef NDEBUG 
		LogInfos (hdc);
		
	
		// %md���� %ld������	 %m.nf���ƿ��Ⱥ�С��λ�������� �ַ���sprintf(s, "%s love %s.", who, whom)
		// ����16 ���ƴ�ӡ %8xСд16���� %-8X��д16����

		SetBkColor( hdc, RGB( 0, 0, 0 ) );
		// SetBkMode (hdc, TRANSPARENT );     //͸������
		SetTextColor( hdc, RGB(255,255 , 255  ) );

		//  sprintf(cc,"��Ļˢ����Ϊ��%f",g_phy.m_ang);
		wsprintf(cc,"MouseX:%ld",CurMouseX);
		TextOut( hdc, 22, 35, cc, lstrlen(cc) );
		
		wsprintf(cc,"MouseY:%ld",CurMouseY);
		TextOut( hdc, 22, 55, cc, lstrlen(cc) );
		
 		sprintf(cc,"farmecont:%ld",farmecont);
 		TextOut( hdc, 22, 75, cc, lstrlen(cc) );

		#endif


		/*
		*/
		//		RECT Updata_rect={3,BACK_HEIGHT ,BACK_WIDTH-10,0};
		//		InvalidateRect(hWnd,&Updata_rect,FALSE); 
	
		
		int INTGR;
		for (INTGR=0;INTGR<11;INTGR++)
		{
			for (i=0;i<NUM_BALL;i++)
			{
                balls[i].Moveball() ;
			}
			g_phy.Allcollision(&balls[0]);
		} 



		bool allsat=0;
		for (i=0;i<NUM_BALL;i++)
		{	 
		if	(balls[i].bEnable==false) continue;

			if(balls[i].State!=4)
			{allsat=1 ;break;	}
		}
		 //	�����ȫ����ֹ���� ����������״̬ ��ô����Ϊ�û����״̬
		if((allsat==0)&&(GAMEState!=STATE_SET_GAN)) GAMEState=STATE_PLAYER_CONTROL_CUE;  



		if (balls[0].bEnable==false)
		{
 		balls[0].bEnable=true;
		balls[0].binhole=false;
		balls[0].Pos=Vector3(208,260);
		}

		 // \n
		wsprintf(cc,"%ld\n",farmecont);
		 // TRACE(cc,"33w");
		 LogInfo(cc,"54");

		ReleaseDC(hWnd,hdc);
		InvalidateRect(hWnd,NULL,FALSE);

 bwm_mousemove=0;
bwm_lbuttonup=0;
 bwm_lbuttondown=0;
	} //END(GetTickCount()-fps)>15
	
}


 //////////////////////////////////////////////////////
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	// TODO: Place code here.
	MSG msg;
	ZeroMemory( &msg, sizeof(msg) );
	HACCEL hAccelTable;
	
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}
	
	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_ZQ);
	fps=GetTickCount();
	// Main message loop:
	while ( msg.message!=WM_QUIT) 
	{
		if (PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE )) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}	
		else {
			
			paint();}
		
	}return msg.wParam;
}


BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX); 
	wcex.style			=  CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInst;
	wcex.hIcon			= LoadIcon(hInst, (LPCTSTR)IDI_ZQ);
	wcex.hCursor		= LoadCursor (NULL, IDC_ARROW) ;;
	wcex.hbrBackground	= NULL;
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName= "Billard";
	wcex.hIconSm		= NULL;
	RegisterClassEx(&wcex);
	
	hInst = hInstance; // Store instance handle in our global variable
	
	hWnd = CreateWindow("Billard", "Billard Gold", WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,,
		CW_USEDEFAULT, 0, 600, 600, NULL, NULL, hInstance, NULL);

	


	if (!hWnd)
	{
		return FALSE;
	}
	
	Init();
	
	
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	OnCreate(hWnd); 
	
	return TRUE;
}



LRESULT WINAPI WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	RECT rects={0,1000,1000,0};
	HDC hdc;
	
	switch (message) 
	{
		
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: Add any drawing code here...
		// paint(hdc);
		
		EndPaint(hWnd,&ps);
		break;
		
	case WM_CREATE:
		// OnCreate(hWnd);
		break;
		
		
	case WM_KEYDOWN :
		
		break;
		
	case WM_LBUTTONDOWN :
		 bwm_lbuttondown=1;

		CurMouseX=LOWORD (lParam);
		CurMouseY=BACK_HEIGHT-HIWORD (lParam);
		

		break;
		
				case WM_LBUTTONUP :
					bwm_lbuttonup=1;
			
					break;
					
				case WM_MOUSEMOVE :
					bwm_mousemove=1;

					CurMouseX=LOWORD (lParam);
					CurMouseY=BACK_HEIGHT-HIWORD (lParam);

					break;
					
				case WM_DESTROY:
					StopLogging();
					PostQuitMessage(0);
					break;
					
				default:
					return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}


//����������
 VOID SETVeroll	(float force) 
{					 
	 force=Max(force,3.0f);
	 force=Min(force,130.0f);

 					  hitforce=	force;

						gdipic.iniTex(g_HitForceVeroll.m_pBits,g_HitForceVeroll.m_nPitch,g_Heading.m_pBits,g_Heading.m_nPitch);
						gdipic.ProssVeroll( force,g_HitForceVeroll.m_nWidth,g_HitForceVeroll.m_nHeight);
						//����������

						gdipic.ShaderTEXCOLOR(445,29,g_HitForceVeroll.m_nWidth,g_HitForceVeroll.m_nHeight);

 }

 //���û����
 VOID SEThitPoint(float Px, float Py)	  
{

 				HIT_MUBX=Px ,HIT_MUBY= Py;
			
			//�������׼��
			gdipic.iniTex(g_HitBall.m_pBits,g_HitBall.m_nPitch,g_Heading.m_pBits,g_Heading.m_nPitch);
			gdipic.ShaderTEXCOLOR(375,11,g_HitBall.m_nWidth,g_HitBall.m_nHeight,NULL) ;
			
			gdipic.iniTex(g_HitMarker.m_pBits,g_HitMarker.m_nPitch,g_Heading.m_pBits,g_Heading.m_nPitch);
			gdipic.ShaderTEX(HIT_MUBX+400,HIT_MUBY+36,g_HitMarker.m_nWidth,g_HitMarker.m_nHeight,BLEND_MULT,NULL) ;
			

   	 //���ƻ����

 }
	 
//��ʼ�����
  VOID StarhitBall()
  {
   				Vector3 VTMP , Bpos;
			Bpos = balls[0].Pos;
			VTMP = NormaliseVector((Vector3(CurMouseX, CurMouseY)-Bpos));
			
			Vector3 hitp ; //�����		  
			hitp = RotateZ(VTMP, PI_DIV2)* (-balls[0].Rbou * HIT_MUBX/20) ;
			hitp += Bpos;
			hitp = Vector3(hitp.X, hitp.Y, -balls[0].Rbou * HIT_MUBY/20)	;
			// balls[0].applyimpulse ((VTMP* hitforce / 20), hitp) ;

			 	//����״̬
			  hitSTATEimpulse=(VTMP* hitforce / 15);
 hitSTATEPnt=hitp;
 hitSTATEang=g_phy.m_ang ;


			GAMEState=STATE_SET_GAN;

  }

   bool inRect( float X,float Y, RECT &rects)
   {
	if(X>rects.left&& X<rects.right && Y>rects.bottom && Y<rects.top)
		return true;
	else 
	  	return false;

   }

  bool swapgan( float &desten)
  {
	  static int XI=0; 

	 XI++;
	 if (XI<18)	
	 {
		 desten=XI*2;
	    return false;
	 }
	  else if(XI<=20)
	  {
		  desten=(20-XI)*10;
		  return false;
	  }
	 else if (XI==21)
	 {
	  XI=0;
	  desten=0;
	 return true;
	 }
	 // else


 return true;
	  
  }