
#if !defined(ZQ_H)
#define ZQ_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#endif 