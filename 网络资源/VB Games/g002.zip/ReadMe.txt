The Haunted Maze 2 - By Simon Price

Description : A pac-man style game where you have to collect bones without tany ghosts touching you.

New Features : 3D Mazes, different levels of ghost activity, clever AI uses the ghosts line of sight.

How to Play : Use the arrow keys to move around, press P to pause/upause the action.

How to create your own levels : Select 'Level Creator' from the File menu. There you can draw walls on the square level preview with the mouse. To erase walls, re-draw back over them. On the left on the screen will be options to change the wall type (28 to choose from!) or floor type (30 to choose from!). Then go to File - Save and type a name for your level. Then you will be able to select your level next time you play! You can create larger levels by selecting File - New but be sure to type a number between 10 and 100 for them maze size - otherwise you might get an error!

Comments : If you have any comments on this game please send e-mail to : KingSimon@HisPalace.fsbusiness.co.uk. If you would like to try the original version of this game (much more fun than this version, but with 2D graphics) you can download it from my wbsite at : www.hispalace.fsbusiness.co.uk

Rules : You may distribute only the zip file this came in, or if you which to distribute a non zip file, then you must distribute the whole folder this came in including all it's contents.