Painting Rendering 

www.vbgamedev.com      -zh1110
